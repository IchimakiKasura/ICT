#include <CTime>
#include "console.hpp"
#include "students.hpp"

int main()
{
    Student("Name", "9", "ICT").add();

    return EXIT_SUCCESS;
}
